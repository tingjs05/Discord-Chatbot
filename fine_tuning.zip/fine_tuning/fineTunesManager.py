from dotenv import load_dotenv
from pprint import pprint
import requests
import openai
import os
import csv
import json

'''
======================================================================================

This code is a modified version of David Shappiro's example code on a 'Plot Generator'
Aka I yeeted most of these stuff from him :)

Link to github:
https://github.com/daveshap/PlotGenerator

======================================================================================
'''

load_dotenv()

#get api key
GPT_API_KEY = os.getenv("GPT_API_KEY")
openai.api_key = GPT_API_KEY

def file_upload(filename, purpose='fine-tune'):
    respond = openai.File.create(purpose=purpose, file=open(filename))
    pprint(respond)
    return respond

#fine tune model
def file_list():
    respond = openai.File.list()
    pprint(respond)


def finetune_model(fileid, suffix, model='davinci'):
    header = {
        'Content-Type': 'application/json', 
        'Authorization': f'Bearer {GPT_API_KEY}'
    }
    payload = {
        'training_file': fileid, 
        'model': model, 
        'suffix': suffix
    }
    respond = requests.request(method='POST', url='https://api.openai.com/v1/fine-tunes', json=payload, headers=header, timeout=45)
    pprint(respond.json())


def finetune_list():
    header = {
        'Content-Type': 'application/json', 
        'Authorization': f'Bearer {GPT_API_KEY}'
    }
    respond = requests.request(method='GET', url='https://api.openai.com/v1/fine-tunes', headers=header, timeout=45)
    pprint(respond.json())


def finetune_events(ftid):
    header = {
        'Content-Type': 'application/json', 
        'Authorization': f'Bearer {GPT_API_KEY}'
    }
    respond = requests.request(method='GET', url='https://api.openai.com/v1/fine-tunes/%s/events' % ftid, headers=header, timeout=45)    
    pprint(respond.json())


def finetune_get(ftid):
    header = {
        'Content-Type': 'application/json', 
        'Authorization': f'Bearer {GPT_API_KEY}'
    }
    respond = requests.request(method='GET', url='https://api.openai.com/v1/fine-tunes/%s' % ftid, headers=header, timeout=45)    
    pprint(respond.json())

#prepare data set
def convertCSV():
    data = []
    #get data from csv
    with open("fine_tuning/fine_tunes.csv", 'r', encoding="utf-8", newline="") as file:
        with open("fine_tuning/used_data.csv", 'a', encoding="utf-8", newline="") as saveFile:
            #declare csv readers and writers
            reader = csv.reader(file)
            writer = csv.writer(saveFile)

            #loop through all the data
            for i, row in enumerate(reader):
                if i != 0:
                    #append to data list
                    data.append({
                        "prompt": row[0], 
                        "completion": row[1]
                    })
                    #write data to user_data.csv
                    writer.writerow((
                        row[0], 
                        row[1]
                    ))
            
    #reset fine_tunes.csv by rewriting it
    with open("fine_tuning/fine_tunes.csv", 'w', encoding="utf-8", newline="") as file:
        #declare csv readers and writers
        writer = csv.writer(file)

        #write headers
        writer.writerow((
            "prompt", 
            "completion"
        ))

    #save data to a .jsonl file
    with open('fine_tuning/fine-tunes.jsonl', 'w', encoding="utf-8", newline="") as f:
        for i in data:
            json.dump(i, f)
            f.write('\n')

#main
if __name__ == "__main__":
    while True:
        print("1. Convert CSV\n2. Fine Tune Model\n3. List Fine Tunes\n4. Fine Tune Events\n5. Get Fine Tune\n6. Cancel Fine Tune\nX. Exit Program")
        choice = input("choice: ")

        #validate input
        while choice not in ("1", "2", "3", "4", "5", "6", "x", "X"):
            choice = input("choice (1 - 6): ")
        #break out of the loop if choice is "x" or "X" to exit the program
        if not choice.isdigit():
            break
        #otherwise convert choice to an integer
        choice = int(choice)

        #seperate output
        print("\n")

        #call functions
        if choice == 1:
            convertCSV()
        elif choice == 2:
            respond = file_upload('fine_tuning/fine-tunes.jsonl')
            finetune_model(respond['id'], 'rosmontis-chatbot-001', 'davinci')
        elif choice == 3:
            finetune_list()
        elif choice == 4:
            ftid = input("ftid: ")
            finetune_events(ftid)
        elif choice == 5:
            ftid = input("ftid: ")
            finetune_get(ftid)
        elif choice == 6:
            ftid = input("ftid: ")
            openai.FineTune.cancel(ftid)

        #seperate next instruction from previous instruction
        print("\n" * 2)